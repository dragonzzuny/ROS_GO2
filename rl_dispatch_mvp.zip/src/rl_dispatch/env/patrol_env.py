"""
PatrolEnv: Gymnasium environment for patrol robot dispatch and rescheduling.

This environment implements a Semi-Markov Decision Process (SMDP) where:
- State: Robot state, patrol points, events, LiDAR, candidates
- Actions: Composite (dispatch_mode, replan_strategy)
- Rewards: Multi-component (event, patrol, safety, efficiency)
- Time: Variable-duration steps (SMDP, not fixed-timestep MDP)

The environment models a patrol robot that must balance:
1. Responding to CCTV-detected events requiring investigation
2. Maintaining regular patrol coverage of designated waypoints

Key Features:
- SMDP semantics: Each step() corresponds to reaching a Nav2 goal (variable time)
- Action masking: Invalid actions are masked based on state
- Dense rewards: Non-zero rewards at most steps for learning efficiency
- Realistic simulation: Nav2-style navigation with failure modes
"""

from typing import Any, Dict, Optional, Tuple
import numpy as np
import gymnasium as gym
from gymnasium import spaces
from dataclasses import replace

from rl_dispatch.core.types import (
    State,
    RobotState,
    PatrolPoint,
    Event,
    Action,
    ActionMode,
    Candidate,
    Observation,
    RewardComponents,
    EpisodeMetrics,
)
from rl_dispatch.core.config import EnvConfig, RewardConfig
from rl_dispatch.planning import CandidateFactory
from rl_dispatch.navigation import NavigationInterface, SimulatedNav2
from rl_dispatch.rewards import RewardCalculator
from rl_dispatch.utils import ObservationProcessor


class PatrolEnv(gym.Env):
    """
    Gymnasium environment for patrol robot dispatch and rescheduling.

    This environment models the complete patrol dispatch problem including:
    - Dynamic event generation (simulating CCTV detections)
    - Nav2-style navigation with variable execution times
    - Multi-objective reward function
    - Action masking for feasibility constraints

    Observation Space:
        Box(77,) - Normalized 77D observation vector:
        - Goal relative position (2D)
        - Robot heading sin/cos (2D)
        - Velocity/angular velocity (2D)
        - Battery level (1D)
        - LiDAR ranges (64D)
        - Event features (4D)
        - Patrol features (2D)

    Action Space:
        MultiDiscrete([2, K]) where K is number of candidate strategies:
        - action[0]: Mode (0=patrol, 1=dispatch)
        - action[1]: Replan strategy index (0 to K-1)

    Rewards:
        Float scalar - weighted sum of:
        - Event response reward
        - Patrol coverage reward
        - Safety reward
        - Efficiency reward

    Episode Termination:
        - Max steps reached
        - Max time reached
        - Battery depleted
        - Terminal collision

    Example:
        >>> env_config = EnvConfig()
        >>> reward_config = RewardConfig()
        >>> env = PatrolEnv(env_config, reward_config)
        >>> obs, info = env.reset()
        >>> action = env.action_space.sample()
        >>> obs, reward, terminated, truncated, info = env.step(action)
    """

    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 30}

    def __init__(
        self,
        env_config: Optional[EnvConfig] = None,
        reward_config: Optional[RewardConfig] = None,
    ):
        """
        Initialize PatrolEnv.

        Args:
            env_config: Environment configuration (uses defaults if None)
            reward_config: Reward configuration (uses defaults if None)
        """
        super().__init__()

        # Configuration
        self.env_config = env_config or EnvConfig()
        self.reward_config = reward_config or RewardConfig()

        # Initialize subsystems
        self.candidate_factory = CandidateFactory()
        self.reward_calculator = RewardCalculator(self.reward_config)
        self.obs_processor = ObservationProcessor(
            use_normalization=False,  # Normalization handled externally during training
            max_goal_distance=max(self.env_config.map_width, self.env_config.map_height),
            max_velocity=self.env_config.robot_max_velocity,
            max_angular_velocity=self.env_config.robot_max_angular_velocity,
            max_lidar_range=self.env_config.lidar_max_range,
        )

        # Initialize navigation interface (SimulatedNav2 for training)
        # Will be initialized with proper random state in reset()
        self.nav_interface: Optional[NavigationInterface] = None

        # Define action and observation spaces
        self.action_space = spaces.MultiDiscrete([
            2,  # Mode: 0=patrol, 1=dispatch
            self.env_config.num_candidates,  # Replan strategy index
        ])

        self.observation_space = spaces.Box(
            low=-np.inf,
            high=np.inf,
            shape=(77,),
            dtype=np.float32,
        )

        # Episode state (initialized in reset())
        self.current_state: Optional[State] = None
        self.episode_step: int = 0
        self.episode_metrics: EpisodeMetrics = EpisodeMetrics()
        self.current_patrol_route: list = []
        self.pending_event: Optional[Event] = None
        self.event_counter: int = 0
        self.last_position: Tuple[float, float] = (0.0, 0.0)

        # Random number generator (seeded in reset())
        self.np_random: np.random.Generator = None

    def reset(
        self,
        seed: Optional[int] = None,
        options: Optional[Dict[str, Any]] = None,
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """
        Reset environment to initial state.

        Args:
            seed: Random seed for reproducibility
            options: Optional reset parameters (unused)

        Returns:
            observation: Initial 77D observation
            info: Dictionary with episode info
        """
        # Seed RNG
        super().reset(seed=seed)
        self.np_random = np.random.default_rng(seed)

        # Initialize navigation interface with seeded random state
        self.nav_interface = SimulatedNav2(
            max_velocity=self.env_config.robot_max_velocity,
            nav_failure_rate=0.05,
            collision_rate=0.01,
            np_random=np.random.RandomState(seed),
        )

        # Initialize robot at random patrol point
        initial_point_idx = self.np_random.integers(0, self.env_config.num_patrol_points)
        initial_point = self.env_config.patrol_points[initial_point_idx]

        robot = RobotState(
            x=initial_point[0],
            y=initial_point[1],
            heading=self.np_random.uniform(0, 2 * np.pi),
            velocity=0.0,
            angular_velocity=0.0,
            battery_level=1.0,
            current_goal_idx=0,  # Start going to first patrol point
        )

        # Initialize patrol points with visit times
        patrol_points = tuple(
            PatrolPoint(
                x=pos[0],
                y=pos[1],
                last_visit_time=0.0 if i == initial_point_idx else -100.0,  # Start overdue
                priority=self.env_config.patrol_point_priorities[i],
                point_id=i,
            )
            for i, pos in enumerate(self.env_config.patrol_points)
        )

        # Initialize patrol route (randomized for better exploration during training)
        self.current_patrol_route = list(range(self.env_config.num_patrol_points))
        self.np_random.shuffle(self.current_patrol_route)

        # Generate initial candidates
        candidates = self.candidate_factory.generate_all(
            robot, patrol_points, current_time=0.0
        )

        # Initialize LiDAR (all clear initially)
        lidar_ranges = np.full(
            self.env_config.lidar_num_channels,
            self.env_config.lidar_max_range,
            dtype=np.float32,
        )

        # Create initial state
        self.current_state = State(
            robot=robot,
            patrol_points=patrol_points,
            current_event=None,
            current_time=0.0,
            candidates=candidates,
            lidar_ranges=lidar_ranges,
        )

        # Reset episode tracking
        self.episode_step = 0
        self.episode_metrics = EpisodeMetrics()
        self.pending_event = None
        self.event_counter = 0
        self.last_position = (robot.x, robot.y)

        # Generate observation
        obs = self.obs_processor.process(self.current_state, update_stats=False)

        info = {
            "episode_step": 0,
            "current_time": 0.0,
            "has_event": False,
        }

        return obs.vector, info

    def step(
        self,
        action: np.ndarray,
    ) -> Tuple[np.ndarray, float, bool, bool, Dict[str, Any]]:
        """
        Execute one SMDP step (navigate to goal, then decide next action).

        This is a Semi-Markov step, meaning it takes variable time depending on
        the navigation goal distance and complexity. The step sequence is:

        1. Parse action (mode, replan_idx)
        2. Apply action masking (check feasibility)
        3. Execute navigation to goal (variable time)
        4. Update robot state and patrol visits
        5. Handle event resolution
        6. Generate/update events
        7. Calculate reward
        8. Check termination conditions
        9. Generate next candidates and observation

        Args:
            action: [mode, replan_idx] - dispatch decision and replan strategy

        Returns:
            observation: Next 77D observation
            reward: Scalar reward for this transition
            terminated: Whether episode ended (goal reached or failure)
            truncated: Whether episode was cut off (time/step limit)
            info: Dictionary with transition details
        """
        assert self.current_state is not None, "Must call reset() before step()"

        # Parse action
        mode = ActionMode(int(action[0]))
        replan_idx = int(action[1])
        action_obj = Action(mode=mode, replan_idx=replan_idx)

        # Apply action masking (log warning if invalid)
        if not self._is_action_valid(action_obj):
            print(f"Warning: Invalid action {action_obj} - adjusting to PATROL mode")
            action_obj = Action(mode=ActionMode.PATROL, replan_idx=replan_idx)

        # Determine navigation goal based on action
        goal_pos, goal_idx = self._determine_navigation_goal(action_obj)

        # Navigate to goal using Nav2 interface (SMDP: variable time)
        robot = self.current_state.robot
        start_pos = (robot.x, robot.y)
        nav_result = self.nav_interface.navigate_to_goal(start_pos, goal_pos)
        nav_time, nav_success, collision = nav_result.time, nav_result.success, nav_result.collision

        # Update robot state
        new_robot = self._update_robot_state(
            goal_pos=goal_pos,
            goal_idx=goal_idx,
            nav_time=nav_time,
            nav_success=nav_success,
        )

        # Update current time
        new_time = self.current_state.current_time + nav_time

        # Check for patrol point visit
        patrol_point_visited = None
        if mode == ActionMode.PATROL and nav_success:
            patrol_point_visited = goal_idx
            # Remove visited point from current route
            if (len(self.current_patrol_route) > 0 and
                self.current_patrol_route[0] == goal_idx):
                self.current_patrol_route.pop(0)

        # Update patrol points with new visit time
        new_patrol_points = self._update_patrol_points(
            patrol_point_visited=patrol_point_visited,
            current_time=new_time,
        )

        # Update patrol route if replan was selected
        if replan_idx > 0:  # 0 is keep-order
            candidate = self.current_state.candidates[replan_idx]
            self.current_patrol_route = list(candidate.patrol_order)

        # Handle event resolution
        event_resolved = False
        if mode == ActionMode.DISPATCH and self.pending_event and nav_success:
            event_resolved = True
            self.episode_metrics.events_responded += 1
            self.episode_metrics.events_successful += 1
            # Update average delay
            delay = new_time - self.pending_event.detection_time
            n = self.episode_metrics.events_responded
            self.episode_metrics.avg_event_delay = (
                (self.episode_metrics.avg_event_delay * (n - 1) + delay) / n
            )
            self.pending_event = None  # Event resolved

        # Generate new events (Poisson process)
        new_event = self._maybe_generate_event(new_time, nav_time)
        if new_event and self.pending_event is None:
            self.pending_event = new_event
            self.episode_metrics.events_detected += 1

        # Update LiDAR (simulate obstacles)
        new_lidar = self._simulate_lidar(new_robot)

        # Generate new candidates for next decision
        new_candidates = self.candidate_factory.generate_all(
            new_robot, new_patrol_points, new_time
        )

        # Create new state
        new_state = State(
            robot=new_robot,
            patrol_points=new_patrol_points,
            current_event=self.pending_event,
            current_time=new_time,
            candidates=new_candidates,
            lidar_ranges=new_lidar,
        )

        # Calculate distance traveled
        distance_traveled = np.sqrt(
            (new_robot.x - self.last_position[0]) ** 2 +
            (new_robot.y - self.last_position[1]) ** 2
        )
        self.last_position = (new_robot.x, new_robot.y)

        # Calculate reward
        rewards = self.reward_calculator.calculate(
            robot=new_robot,
            action=action_obj,
            event=self.pending_event,
            patrol_points=new_patrol_points,
            current_time=new_time,
            distance_traveled=distance_traveled,
            collision=collision,
            nav_failure=not nav_success,
            event_resolved=event_resolved,
            patrol_point_visited=patrol_point_visited,
        )

        # Update episode metrics
        self.episode_step += 1
        self.episode_metrics.episode_length = self.episode_step
        self.episode_metrics.episode_return += rewards.total
        self.episode_metrics.total_distance += distance_traveled
        self.episode_metrics.final_battery = new_robot.battery_level
        if collision or not nav_success:
            self.episode_metrics.safety_violations += 1

        # Check termination conditions
        terminated = collision or new_robot.battery_level <= 0.0
        truncated = (
            self.episode_step >= self.env_config.max_episode_steps or
            new_time >= self.env_config.max_episode_time
        )

        # Calculate patrol coverage ratio
        if truncated or terminated:
            expected_visits = new_time / (new_time / self.env_config.num_patrol_points)
            actual_visits = sum(
                1 for p in new_patrol_points
                if new_time - p.last_visit_time < new_time / self.env_config.num_patrol_points
            )
            self.episode_metrics.patrol_coverage_ratio = min(1.0, actual_visits / max(1, expected_visits))

        # Update state
        self.current_state = new_state

        # Generate observation
        obs = self.obs_processor.process(new_state, update_stats=False)

        # Build info dict
        info = {
            "episode_step": self.episode_step,
            "current_time": new_time,
            "has_event": self.pending_event is not None,
            "action_mode": mode.name,
            "replan_strategy": new_state.candidates[replan_idx].strategy_name,
            "reward_components": {
                "event": rewards.event,
                "patrol": rewards.patrol,
                "safety": rewards.safety,
                "efficiency": rewards.efficiency,
            },
            "nav_success": nav_success,
            "collision": collision,
            "event_resolved": event_resolved,
        }

        # Add episode metrics if done
        if terminated or truncated:
            info["episode"] = {
                "r": self.episode_metrics.episode_return,
                "l": self.episode_metrics.episode_length,
                "events_detected": self.episode_metrics.events_detected,
                "events_responded": self.episode_metrics.events_responded,
                "events_successful": self.episode_metrics.events_successful,
                "avg_event_delay": self.episode_metrics.avg_event_delay,
                "patrol_coverage": self.episode_metrics.patrol_coverage_ratio,
                "safety_violations": self.episode_metrics.safety_violations,
                "total_distance": self.episode_metrics.total_distance,
            }

        return obs.vector, rewards.total, terminated, truncated, info

    def _is_action_valid(self, action: Action) -> bool:
        """
        Check if action is valid given current state.

        Args:
            action: Action to validate

        Returns:
            True if action is valid
        """
        # Cannot dispatch if no event
        if action.mode == ActionMode.DISPATCH and not self.current_state.has_event:
            return False

        # Cannot dispatch if battery too low (reserve 20%)
        if action.mode == ActionMode.DISPATCH and self.current_state.robot.battery_level < 0.2:
            return False

        # Replan index must be valid
        if action.replan_idx >= self.env_config.num_candidates:
            return False

        return True

    def _determine_navigation_goal(
        self,
        action: Action,
    ) -> Tuple[Tuple[float, float], int]:
        """
        Determine navigation goal position based on action.

        Args:
            action: Selected action

        Returns:
            (goal_position, goal_idx): Goal (x, y) and index
        """
        if action.mode == ActionMode.DISPATCH and self.pending_event:
            # Navigate to event location
            return (self.pending_event.x, self.pending_event.y), -1
        else:
            # Navigate to next patrol point in route
            if len(self.current_patrol_route) > 0:
                next_idx = self.current_patrol_route[0]
                point = self.current_state.patrol_points[next_idx]
                return (point.x, point.y), next_idx
            else:
                # Fallback: stay at current position
                return (self.current_state.robot.x, self.current_state.robot.y), -1


    def _update_robot_state(
        self,
        goal_pos: Tuple[float, float],
        goal_idx: int,
        nav_time: float,
        nav_success: bool,
    ) -> RobotState:
        """
        Update robot state after navigation.

        Args:
            goal_pos: Target position
            goal_idx: Target patrol point index (-1 if event)
            nav_time: Time taken for navigation
            nav_success: Whether navigation succeeded

        Returns:
            Updated RobotState
        """
        robot = self.current_state.robot

        if nav_success:
            # Robot reached goal
            new_x, new_y = goal_pos
            # Update heading towards goal
            dx = goal_pos[0] - robot.x
            dy = goal_pos[1] - robot.y
            new_heading = np.arctan2(dy, dx)
        else:
            # Navigation failed - robot stays roughly in same position
            new_x = robot.x + self.np_random.normal(0, 0.1)
            new_y = robot.y + self.np_random.normal(0, 0.1)
            new_heading = robot.heading

        # Update battery (drain based on time and distance)
        distance = np.sqrt((new_x - robot.x) ** 2 + (new_y - robot.y) ** 2)
        energy_used = (nav_time / 3600.0) * self.env_config.robot_battery_drain_rate
        battery_drain = energy_used / self.env_config.robot_battery_capacity
        new_battery = max(0.0, robot.battery_level - battery_drain)

        # Update velocity (moving at average speed during navigation)
        new_velocity = distance / nav_time if nav_time > 0 else 0.0

        return RobotState(
            x=new_x,
            y=new_y,
            heading=new_heading,
            velocity=min(new_velocity, self.env_config.robot_max_velocity),
            angular_velocity=0.0,
            battery_level=new_battery,
            current_goal_idx=goal_idx,
        )

    def _update_patrol_points(
        self,
        patrol_point_visited: Optional[int],
        current_time: float,
    ) -> Tuple[PatrolPoint, ...]:
        """
        Update patrol points with new visit time.

        Args:
            patrol_point_visited: Index of visited point (None if none)
            current_time: Current episode time

        Returns:
            Updated tuple of PatrolPoints
        """
        updated_points = []
        for i, point in enumerate(self.current_state.patrol_points):
            if i == patrol_point_visited:
                # Update visit time
                updated_point = replace(point, last_visit_time=current_time)
            else:
                updated_point = point
            updated_points.append(updated_point)

        return tuple(updated_points)

    def _maybe_generate_event(self, current_time: float, step_duration: float) -> Optional[Event]:
        """
        Possibly generate a new event (Poisson process).

        Uses industrial safety event types with risk levels (1-9) following
        Korean KOSHA/MOEL safety standards.

        Args:
            current_time: Current episode time
            step_duration: Duration of the SMDP step (nav_time)

        Returns:
            New Event if generated, None otherwise
        """
        # Poisson rate: lambda = rate / episode_time
        rate_per_second = self.env_config.event_generation_rate / self.env_config.max_episode_time
        prob_event_this_step = rate_per_second * step_duration  # Use actual step duration

        if self.np_random.random() < prob_event_this_step:
            # Import industrial safety event utilities
            from rl_dispatch.core.event_types import get_random_event_name, get_event_risk_level

            # Generate random event location
            event_x = self.np_random.uniform(0, self.env_config.map_width)
            event_y = self.np_random.uniform(0, self.env_config.map_height)

            # Select event type (risk-weighted: high-risk events are less frequent)
            event_name = get_random_event_name(self.np_random)
            risk_level = get_event_risk_level(event_name)

            # Generate detection confidence
            confidence = self.np_random.uniform(
                self.env_config.event_min_confidence,
                1.0
            )

            self.event_counter += 1

            # Import extended Event class
            from rl_dispatch.core.types_extended import Event as ExtendedEvent

            return ExtendedEvent(
                x=event_x,
                y=event_y,
                risk_level=risk_level,
                event_name=event_name,
                confidence=confidence,
                detection_time=current_time,
                event_id=self.event_counter,
                is_active=True,
            )

        return None

    def _simulate_lidar(self, robot: RobotState) -> np.ndarray:
        """
        Simulate LiDAR range measurements (simplified).

        In real deployment, this would come from actual sensor data.

        Args:
            robot: Current robot state

        Returns:
            64D array of range measurements
        """
        # Simplified: return random ranges with some structure
        # In reality, this would raycast against map obstacles
        ranges = np.full(
            self.env_config.lidar_num_channels,
            self.env_config.lidar_max_range,
            dtype=np.float32,
        )

        # Add some random variation to simulate obstacles
        ranges += self.np_random.normal(0, 0.5, size=ranges.shape)
        ranges = np.clip(ranges, self.env_config.lidar_min_range, self.env_config.lidar_max_range)

        return ranges

    def render(self):
        """Render the environment (not implemented)."""
        pass

    def close(self):
        """Close the environment."""
        pass
