"""
Gymnasium environment for patrol robot dispatch and rescheduling.

This module implements the PatrolEnv, a Gymnasium-compatible environment
that models the patrol robot dispatch problem as a Semi-Markov Decision Process (SMDP).

Also includes MultiMapPatrolEnv for training on diverse map configurations
to improve policy generalization.
"""

from rl_dispatch.env.patrol_env import PatrolEnv
from rl_dispatch.env.multi_map_env import MultiMapPatrolEnv, create_multi_map_env

__all__ = ["PatrolEnv", "MultiMapPatrolEnv", "create_multi_map_env"]
