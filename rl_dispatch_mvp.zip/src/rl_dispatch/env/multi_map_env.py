"""
MultiMapPatrolEnv: Environment wrapper for training on multiple map configurations.

This wrapper enables generalization by training on diverse patrol scenarios.
Each episode randomly selects a map configuration, forcing the policy to learn
map-agnostic strategies rather than overfitting to a single layout.

Key Features:
- Automatic map rotation across episodes
- Coverage heatmap tracking for visualization
- Per-map performance metrics
- Seamless integration with existing training code
"""

from typing import Any, Dict, List, Optional, Tuple
import numpy as np
import gymnasium as gym
from pathlib import Path
import random

from rl_dispatch.core.config import EnvConfig, RewardConfig
from rl_dispatch.env.patrol_env import PatrolEnv


class MultiMapPatrolEnv(gym.Env):
    """
    Wrapper environment that trains on multiple map configurations.

    This environment wraps multiple PatrolEnv instances, each with a different
    map configuration. On each reset(), it randomly selects one map to use for
    the episode, enabling the policy to generalize across diverse scenarios.

    Attributes:
        config_paths: List of paths to map configuration YAML files
        current_env: Currently active PatrolEnv instance
        current_map_name: Name of current map configuration
        map_stats: Performance statistics per map
        coverage_heatmaps: Spatial coverage tracking per map

    Example:
        >>> config_paths = [
        ...     "configs/map_large_square.yaml",
        ...     "configs/map_corridor.yaml",
        ...     "configs/map_office_building.yaml",
        ... ]
        >>> env = MultiMapPatrolEnv(config_paths)
        >>> obs, info = env.reset()  # Random map selected
        >>> print(info["map_name"])  # "map_large_square"
    """

    metadata = {"render_modes": ["human", "rgb_array"]}

    def __init__(
        self,
        config_paths: List[str],
        reward_config: Optional[RewardConfig] = None,
        render_mode: Optional[str] = None,
        map_selection_mode: str = "random",  # "random", "sequential", "curriculum"
        track_coverage: bool = True,
        heatmap_resolution: float = 2.0,  # meters per grid cell
    ):
        """
        Initialize multi-map environment.

        Args:
            config_paths: List of paths to map configuration YAML files
            reward_config: Shared reward configuration (optional)
            render_mode: Rendering mode for visualization
            map_selection_mode: How to select maps ("random", "sequential", "curriculum")
            track_coverage: Whether to track spatial coverage heatmaps
            heatmap_resolution: Grid cell size for coverage tracking (meters)
        """
        super().__init__()

        assert len(config_paths) > 0, "Must provide at least one config path"

        self.config_paths = config_paths
        self.reward_config = reward_config or RewardConfig()
        self.render_mode = render_mode
        self.map_selection_mode = map_selection_mode
        self.track_coverage = track_coverage
        self.heatmap_resolution = heatmap_resolution

        # Load all environment configurations
        self.env_configs: Dict[str, EnvConfig] = {}
        for path in config_paths:
            config = EnvConfig.load_yaml(path)
            map_name = Path(path).stem  # e.g., "map_large_square"
            self.env_configs[map_name] = config

        self.map_names = list(self.env_configs.keys())

        # Create initial environment (will be recreated on reset)
        first_config = self.env_configs[self.map_names[0]]
        self.current_env = PatrolEnv(
            env_config=first_config,
            reward_config=self.reward_config,
        )
        self.current_map_name = self.map_names[0]

        # Observation and action spaces (use first env as template)
        self.observation_space = self.current_env.observation_space
        self.action_space = self.current_env.action_space

        # Tracking
        self.episode_count = 0
        self.map_selection_history: List[str] = []
        self.map_stats: Dict[str, Dict[str, List[float]]] = {
            name: {
                "returns": [],
                "event_success_rate": [],
                "patrol_coverage": [],
                "avg_response_time": [],
            }
            for name in self.map_names
        }

        # Coverage heatmaps (if enabled)
        self.coverage_heatmaps: Dict[str, np.ndarray] = {}
        if self.track_coverage:
            self._initialize_heatmaps()

    def _initialize_heatmaps(self) -> None:
        """Initialize coverage heatmaps for each map."""
        for map_name, config in self.env_configs.items():
            # Calculate grid dimensions
            width_cells = int(np.ceil(config.map_width / self.heatmap_resolution))
            height_cells = int(np.ceil(config.map_height / self.heatmap_resolution))

            # Initialize heatmap (counts visits to each grid cell)
            self.coverage_heatmaps[map_name] = np.zeros(
                (height_cells, width_cells), dtype=np.int32
            )

    def _select_map(self) -> str:
        """
        Select which map to use for next episode.

        Returns:
            map_name: Name of selected map configuration
        """
        if self.map_selection_mode == "random":
            return random.choice(self.map_names)

        elif self.map_selection_mode == "sequential":
            idx = self.episode_count % len(self.map_names)
            return self.map_names[idx]

        elif self.map_selection_mode == "curriculum":
            # Start with smaller/simpler maps, gradually introduce harder ones
            # Heuristic: Use map size as difficulty proxy
            sizes = [
                (
                    name,
                    self.env_configs[name].map_width
                    * self.env_configs[name].map_height,
                )
                for name in self.map_names
            ]
            sorted_by_size = sorted(sizes, key=lambda x: x[1])

            # Linear curriculum: introduce new maps every N episodes
            curriculum_step = min(
                len(self.map_names) - 1, self.episode_count // 100
            )
            available_maps = [name for name, _ in sorted_by_size[: curriculum_step + 1]]

            return random.choice(available_maps)

        else:
            raise ValueError(f"Unknown map_selection_mode: {self.map_selection_mode}")

    def _update_coverage_heatmap(self, position: Tuple[float, float]) -> None:
        """Update coverage heatmap with robot position."""
        if not self.track_coverage:
            return

        x, y = position
        config = self.env_configs[self.current_map_name]

        # Convert position to grid coordinates
        grid_x = int(x / self.heatmap_resolution)
        grid_y = int(y / self.heatmap_resolution)

        # Bounds check
        heatmap = self.coverage_heatmaps[self.current_map_name]
        if 0 <= grid_y < heatmap.shape[0] and 0 <= grid_x < heatmap.shape[1]:
            heatmap[grid_y, grid_x] += 1

    def reset(
        self, *, seed: Optional[int] = None, options: Optional[Dict[str, Any]] = None
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """
        Reset environment with a new map configuration.

        Args:
            seed: Random seed
            options: Additional options (can include "map_name" to force specific map)

        Returns:
            observation: Initial observation
            info: Info dict with map_name and other metadata
        """
        super().reset(seed=seed)

        # Select map
        if options and "map_name" in options:
            map_name = options["map_name"]
            assert map_name in self.map_names, f"Unknown map: {map_name}"
        else:
            map_name = self._select_map()

        # Create new environment if map changed
        if map_name != self.current_map_name or self.current_env is None:
            config = self.env_configs[map_name]
            self.current_env = PatrolEnv(
                env_config=config,
                reward_config=self.reward_config,
            )
            self.current_map_name = map_name

        # Reset underlying environment
        obs, info = self.current_env.reset(seed=seed)

        # Update tracking
        self.episode_count += 1
        self.map_selection_history.append(map_name)
        info["map_name"] = map_name
        info["episode_count"] = self.episode_count
        info["map_stats"] = self.get_map_statistics()

        return obs, info

    def step(
        self, action: np.ndarray
    ) -> Tuple[np.ndarray, float, bool, bool, Dict[str, Any]]:
        """
        Execute action in current environment.

        Args:
            action: Action to execute

        Returns:
            observation: Next observation
            reward: Reward received
            terminated: Whether episode ended
            truncated: Whether episode was truncated
            info: Additional information
        """
        obs, reward, terminated, truncated, info = self.current_env.step(action)

        # Update coverage heatmap
        robot_pos = self.current_env.current_state.robot.position  # Already a tuple (x, y)
        self._update_coverage_heatmap(robot_pos)

        # Add map info
        info["map_name"] = self.current_map_name

        # Track episode stats on termination
        if terminated or truncated:
            metrics = self.current_env.episode_metrics
            stats = self.map_stats[self.current_map_name]

            stats["returns"].append(metrics.episode_return)
            stats["event_success_rate"].append(metrics.event_success_rate)
            stats["patrol_coverage"].append(metrics.patrol_coverage_ratio)
            stats["avg_response_time"].append(metrics.avg_event_delay)

            info["map_episode_metrics"] = metrics

        return obs, reward, terminated, truncated, info

    def render(self) -> Optional[np.ndarray]:
        """Render current environment."""
        return self.current_env.render()

    def close(self) -> None:
        """Close environment."""
        if self.current_env is not None:
            self.current_env.close()

    def get_map_statistics(self) -> Dict[str, Dict[str, float]]:
        """
        Get performance statistics for each map.

        Returns:
            stats: Dict mapping map_name to performance metrics
        """
        result = {}
        for map_name, stats in self.map_stats.items():
            if len(stats["returns"]) > 0:
                result[map_name] = {
                    "episodes": len(stats["returns"]),
                    "mean_return": np.mean(stats["returns"]),
                    "std_return": np.std(stats["returns"]),
                    "mean_event_success": np.mean(stats["event_success_rate"]),
                    "mean_patrol_coverage": np.mean(stats["patrol_coverage"]),
                    "mean_response_time": np.mean(stats["avg_response_time"]),
                }
            else:
                result[map_name] = {
                    "episodes": 0,
                    "mean_return": 0.0,
                    "std_return": 0.0,
                    "mean_event_success": 0.0,
                    "mean_patrol_coverage": 0.0,
                    "mean_response_time": 0.0,
                }

        return result

    def get_coverage_heatmap(self, map_name: str) -> Optional[np.ndarray]:
        """
        Get coverage heatmap for a specific map.

        Args:
            map_name: Name of map

        Returns:
            heatmap: 2D array of visit counts (or None if tracking disabled)
        """
        if not self.track_coverage:
            return None

        return self.coverage_heatmaps.get(map_name, None)

    def get_all_coverage_heatmaps(self) -> Dict[str, np.ndarray]:
        """Get all coverage heatmaps."""
        return self.coverage_heatmaps.copy()

    def print_statistics(self) -> None:
        """Print summary statistics for all maps."""
        print("\n" + "=" * 80)
        print("Multi-Map Training Statistics")
        print("=" * 80)
        print(f"Total Episodes: {self.episode_count}")
        print(f"Map Selection Mode: {self.map_selection_mode}")
        print(f"\nMap Usage:")

        stats = self.get_map_statistics()
        for map_name in self.map_names:
            s = stats[map_name]
            count = self.map_selection_history.count(map_name)
            pct = 100.0 * count / max(1, self.episode_count)

            print(f"\n  {map_name}:")
            print(f"    Episodes: {s['episodes']} ({pct:.1f}%)")
            if s["episodes"] > 0:
                print(f"    Mean Return: {s['mean_return']:.1f} ± {s['std_return']:.1f}")
                print(f"    Event Success: {100*s['mean_event_success']:.1f}%")
                print(f"    Patrol Coverage: {100*s['mean_patrol_coverage']:.1f}%")
                print(f"    Avg Response Time: {s['mean_response_time']:.1f}s")

        print("\n" + "=" * 80)


def create_multi_map_env(
    map_configs: Optional[List[str]] = None,
    mode: str = "random",
    **kwargs
) -> MultiMapPatrolEnv:
    """
    Factory function to create multi-map environment.

    Args:
        map_configs: List of config paths (uses defaults if None)
        mode: Map selection mode ("random", "sequential", "curriculum")
        **kwargs: Additional arguments passed to MultiMapPatrolEnv

    Returns:
        env: MultiMapPatrolEnv instance

    Example:
        >>> # Use default diverse set
        >>> env = create_multi_map_env()
        >>>
        >>> # Custom map set
        >>> env = create_multi_map_env(
        ...     map_configs=["configs/my_map1.yaml", "configs/my_map2.yaml"],
        ...     mode="curriculum"
        ... )
    """
    if map_configs is None:
        # Default: Use all diverse maps
        base_path = Path(__file__).parent.parent.parent.parent / "configs"
        map_configs = [
            str(base_path / "map_large_square.yaml"),
            str(base_path / "map_corridor.yaml"),
            str(base_path / "map_l_shaped.yaml"),
            str(base_path / "map_office_building.yaml"),
            str(base_path / "map_campus.yaml"),
            str(base_path / "map_warehouse.yaml"),
        ]

    return MultiMapPatrolEnv(
        config_paths=map_configs,
        map_selection_mode=mode,
        **kwargs
    )
