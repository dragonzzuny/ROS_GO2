# Map Configurations

이 디렉토리는 다양한 순찰 맵 설정을 포함합니다.
각 맵은 서로 다른 환경을 대표하여 정책의 일반화 성능을 향상시킵니다.

## 📁 사용 가능한 맵

### 1. `default.yaml` - 기본 테스트 맵
- **크기**: 50m × 50m (약 756평)
- **순찰 포인트**: 4개 (정사각형 패턴)
- **용도**: 빠른 테스트 및 프로토타이핑
- **특징**: 간단하고 대칭적인 구조

```yaml
# 사용 예시
python scripts/train.py --config configs/default.yaml
```

---

### 2. `map_large_square.yaml` - 큰 정사각형 맵
- **크기**: 100m × 100m (약 3,025평)
- **순찰 포인트**: 12개 (외곽 8개 + 내부 4개)
- **용도**: 넓은 공간 순찰 학습
- **특징**:
  - 넓은 개방 공간
  - 외곽 + 내부 순찰 패턴
  - 긴 이동 거리
  - 높은 이벤트 발생률 (12회/에피소드)

```yaml
# 설정 하이라이트
robot_max_velocity: 2.0  # 넓은 공간이라 빠른 속도
event_generation_rate: 12.0
max_episode_time: 900.0  # 15분
```

---

### 3. `map_corridor.yaml` - 복도형 맵
- **크기**: 120m × 30m (약 1,090평)
- **순찰 포인트**: 10개 (직선 배치)
- **용도**: 1차원 긴 경로 최적화
- **특징**:
  - 긴 직선 복도
  - 단순한 경로 구조
  - 입구/출구 중요도 높음

```yaml
# 설정 하이라이트
patrol_point_priorities:
  - 1.5  # 입구 (중요)
  - 1.0  # 중간
  - ...
  - 1.5  # 출구 (중요)
```

---

### 4. `map_l_shaped.yaml` - L자형 건물
- **크기**: 80m × 80m (약 1,450평)
- **순찰 포인트**: 10개 (L자 패턴)
- **용도**: 비정형 공간 학습
- **특징**:
  - L자 형태 복잡한 구조
  - 코너 구역 중요도 높음
  - 다양한 경로 선택 가능

```yaml
# 설정 하이라이트
patrol_points:
  # L자 가로 부분
  - [10.0, 10.0]
  - [25.0, 10.0]
  - [40.0, 10.0]
  ...
  # L자 세로 부분
  - [40.0, 40.0]
  - [40.0, 55.0]
  ...
```

---

### 5. `map_office_building.yaml` - 사무실 건물
- **크기**: 90m × 70m (약 1,900평)
- **순찰 포인트**: 14개 (로비, 복도, 사무실 등)
- **용도**: 복잡한 실내 공간
- **특징**:
  - 여러 구역 (로비, 사무실, 회의실, 비상구)
  - 구역별 중요도 차등
  - 높은 이벤트 발생률 (사람이 많음)
  - 안전 중요도 높음

```yaml
# 설정 하이라이트
patrol_point_priorities:
  - 2.0  # 정문 (매우 중요)
  - 1.8  # 로비
  - 1.6  # 비상구
  - 1.5  # 중앙 교차로
  - ...

robot_max_velocity: 1.2  # 실내라서 느리게
collision_penalty: -150.0  # 사람 많아서 충돌 페널티 크게
```

---

### 6. `map_campus.yaml` - 야외 캠퍼스/단지
- **크기**: 150m × 120m (약 5,445평)
- **순찰 포인트**: 16개 (건물, 광장, 주차장 등)
- **용도**: 넓은 야외 공간, 불규칙한 배치
- **특징**:
  - 매우 넓은 공간
  - 불규칙한 포인트 배치
  - 야외라서 빠른 속도 가능
  - 긴 에피소드 (25분)

```yaml
# 설정 하이라이트
map_width: 150.0
map_height: 120.0
robot_max_velocity: 2.5  # 야외라서 빠르게
event_generation_rate: 18.0  # 넓어서 이벤트 많음
max_episode_time: 1500.0  # 25분
```

---

### 7. `map_warehouse.yaml` - 창고/물류센터
- **크기**: 140m × 100m (약 4,235평)
- **순찰 포인트**: 12개 (하역장, 저장 구역 등)
- **용도**: 넓고 개방된 산업 공간
- **특징**:
  - 하역장 구역 중요
  - 중앙 교차로 매우 중요
  - 작업 이벤트 많음
  - 장비 충돌 위험

```yaml
# 설정 하이라이트
patrol_point_priorities:
  - 1.5  # 하역장들 (중요)
  - 1.8  # 중앙 교차로 (매우 중요)

collision_penalty: -120.0  # 장비 충돌 위험
```

---

## 🎯 맵 선택 가이드

### 학습 목적별 추천

| 목적 | 추천 맵 | 이유 |
|------|---------|------|
| **빠른 테스트** | `default.yaml` | 작고 간단, 빠른 학습 |
| **표준 학습** | `map_large_square.yaml` | 균형잡힌 크기와 복잡도 |
| **복잡한 환경** | `map_office_building.yaml` | 여러 구역, 높은 이벤트 |
| **넓은 공간** | `map_campus.yaml` | 매우 큰 맵, 긴 이동 |
| **일반화 학습** | **모든 맵 혼합** | 다양한 시나리오 |

### 맵 난이도

```
쉬움  ←───────────────────────────────────────────────→  어려움

default  →  corridor  →  large_square  →  l_shaped  →  office  →  warehouse  →  campus
(4점)     (10점)        (12점)          (10점)       (14점)     (12점)        (16점)
```

---

## 🚀 사용 방법

### 1. 단일 맵으로 학습

```bash
# 기본 맵
python scripts/train.py --config configs/default.yaml

# 큰 정사각형 맵
python scripts/train.py --config configs/map_large_square.yaml

# 사무실 맵
python scripts/train.py --config configs/map_office_building.yaml
```

### 2. 여러 맵으로 일반화 학습 (권장!)

```bash
# 기본: 모든 맵 랜덤 선택
python scripts/train_multi_map.py

# 특정 맵들만 선택
python scripts/train_multi_map.py \
  --maps configs/map_large_square.yaml configs/map_office_building.yaml

# 커리큘럼 학습 (쉬운 맵 → 어려운 맵)
python scripts/train_multi_map.py --map-mode curriculum

# 순차 학습 (맵을 순서대로)
python scripts/train_multi_map.py --map-mode sequential
```

### 3. 커버리지 시각화

```bash
# 학습된 모델로 커버리지 확인
python scripts/visualize_coverage.py \
  --model checkpoints/final.pth \
  --episodes-per-map 20

# 랜덤 정책으로 커버리지 확인 (baseline)
python scripts/visualize_coverage.py --episodes-per-map 20
```

### 4. 일반화 성능 평가

```bash
# 여러 맵에서 성능 비교
python scripts/evaluate_generalization.py \
  --model checkpoints/final.pth \
  --episodes 50 \
  --save-json

# 결과: outputs/generalization/ 디렉토리에 저장
# - generalization_results.json
# - generalization_comparison.png
# - return_distribution.png
```

---

## ✏️ 커스텀 맵 만들기

### 기본 템플릿

```yaml
# configs/my_custom_map.yaml

env:
  # 맵 크기 (미터)
  map_width: 60.0
  map_height: 50.0

  # 순찰 포인트 (x, y 좌표)
  patrol_points:
    - [10.0, 10.0]
    - [30.0, 10.0]
    - [50.0, 10.0]
    - [50.0, 40.0]
    - [30.0, 40.0]
    - [10.0, 40.0]

  # 각 포인트의 중요도 (1.0 = 보통, 2.0 = 매우 중요)
  patrol_point_priorities:
    - 1.5  # P0
    - 1.0  # P1
    - 1.0  # P2
    - 1.3  # P3
    - 1.0  # P4
    - 1.2  # P5

  # 에피소드 설정
  max_episode_steps: 250
  max_episode_time: 800.0

  # 이벤트 발생
  event_generation_rate: 8.0
  event_min_urgency: 0.3
  event_max_urgency: 1.0

  # 로봇 설정
  robot_max_velocity: 1.5
  robot_battery_capacity: 150.0

  # 후보 전략 (항상 6개)
  num_candidates: 6
  candidate_strategies:
    - "keep_order"
    - "nearest_first"
    - "most_overdue_first"
    - "overdue_eta_balance"
    - "risk_weighted"
    - "balanced_coverage"

reward:
  # 보상 가중치
  w_event: 1.0
  w_patrol: 0.6
  w_safety: 2.0
  w_efficiency: 0.12

  # 이벤트 보상
  event_response_bonus: 55.0
  event_delay_penalty_rate: 0.55

  # 순찰 보상
  patrol_gap_penalty_rate: 0.12
  patrol_visit_bonus: 2.5

  # 안전 페널티
  collision_penalty: -100.0
  nav_failure_penalty: -20.0

  # 효율성
  distance_penalty_rate: 0.01
```

### 실제 건물 적용 예시

```yaml
# configs/my_building.yaml
# 예: 서울대 302동 1층 (실제 크기 측정 후)

env:
  map_width: 85.0
  map_height: 45.0

  patrol_points:
    - [10.0, 10.0]   # 정문
    - [25.0, 10.0]   # 로비
    - [40.0, 10.0]   # 복도1
    - [55.0, 10.0]   # 복도2
    - [70.0, 10.0]   # 비상구
    - [70.0, 25.0]   # 계단실
    - [70.0, 35.0]   # 실험실A
    - [55.0, 35.0]   # 실험실B
    - [40.0, 35.0]   # 사무실
    - [25.0, 35.0]   # 회의실
    - [10.0, 35.0]   # 휴게실

  patrol_point_priorities:
    - 2.0  # 정문 (매우 중요)
    - 1.8  # 로비
    - 1.0  # 일반 복도
    - 1.0
    - 1.6  # 비상구 (중요)
    - 1.3  # 계단실
    - 1.2  # 실험실들
    - 1.2
    - 1.1  # 사무실
    - 1.0  # 회의실
    - 0.8  # 휴게실 (덜 중요)

  robot_max_velocity: 1.0  # 실내라서 느리게
  event_generation_rate: 12.0
  max_episode_time: 1200.0  # 20분

reward:
  w_event: 1.2  # 실내라서 이벤트 중요
  w_safety: 2.5  # 사람 많아서 안전 매우 중요
  collision_penalty: -150.0
```

---

## 📊 맵 비교표

| 맵 | 크기 (m²) | 평수 | 포인트 | 난이도 | 이벤트율 | 에피소드 시간 | 특징 |
|----|----------|------|--------|--------|----------|--------------|------|
| `default` | 50×50 | 756평 | 4 | ⭐ | 5.0 | 10분 | 기본 테스트 |
| `large_square` | 100×100 | 3,025평 | 12 | ⭐⭐⭐ | 12.0 | 15분 | 넓은 공간 |
| `corridor` | 120×30 | 1,090평 | 10 | ⭐⭐ | 8.0 | 13분 | 1차원 경로 |
| `l_shaped` | 80×80 | 1,450평 | 10 | ⭐⭐⭐ | 10.0 | 14분 | 비정형 공간 |
| `office_building` | 90×70 | 1,900평 | 14 | ⭐⭐⭐⭐ | 14.0 | 16분 | 복잡한 실내 |
| `warehouse` | 140×100 | 4,235평 | 12 | ⭐⭐⭐⭐ | 15.0 | 20분 | 산업 시설 |
| `campus` | 150×120 | 5,445평 | 16 | ⭐⭐⭐⭐⭐ | 18.0 | 25분 | 야외 대규모 |

---

## 💡 팁 & 모범 사례

### 1. 맵 크기 선택
- **100평 이상**: 의미있는 순찰 시나리오
- **너무 작으면**: 학습이 쉽지만 비현실적
- **너무 크면**: 학습 시간 매우 길어짐

### 2. 순찰 포인트 개수
- **최소 2개 이상** 필요
- **4-12개**: 적절한 범위
- **15개 이상**: 학습 어려움, 후보 수 증가 고려

### 3. 우선순위 설정
- **입구/출구**: 1.5-2.0 (중요)
- **일반 구역**: 1.0 (보통)
- **덜 중요한 곳**: 0.7-0.9

### 4. 이벤트 발생률
- **맵 크기에 비례**해서 설정
- 작은 맵: 3-5회/에피소드
- 큰 맵: 10-20회/에피소드

### 5. 로봇 속도
- **실내**: 1.0-1.5 m/s
- **야외**: 1.5-2.5 m/s
- 실제 Go2 최대 속도: ~3.5 m/s

---

## 🔍 문제 해결

### "num_candidates must match number of strategies"
→ `num_candidates: 6`으로 설정하고 `candidate_strategies`에 정확히 6개 전략 나열

### "Must have at least 2 patrol points"
→ `patrol_points`에 최소 2개 이상의 좌표 추가

### "Must have priority for each patrol point"
→ `patrol_point_priorities` 개수 = `patrol_points` 개수

### 학습이 너무 느림
→ 더 작은 맵으로 시작하거나 `max_episode_steps` 줄이기

---

## 📚 참고 자료

- **환경 설정 코드**: `src/rl_dispatch/core/config.py`
- **맵 시각화**: `scripts/visualize_map.py`
- **커버리지 분석**: `scripts/visualize_coverage.py`
- **일반화 평가**: `scripts/evaluate_generalization.py`

---

**마지막 업데이트**: 2025-12-29
**작성자**: 박용준 (YJP)
