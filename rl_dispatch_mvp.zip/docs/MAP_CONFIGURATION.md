# 🗺️ 맵 구성 설명 (Map Configuration)

## 📐 현재 맵 구성

### 기본 설정
- **맵 크기**: 50m × 50m
- **순찰 포인트**: 4개 (정사각형 패턴)

```
맵 레이아웃:
┌─────────────────────────────────────────────────┐ 50m
│                                                 │
│   P3 (10, 40)           42.4m        P2 (40, 40)│ 40m
│        ●━━━━━━━━━━━━━━━━━━━━━━━━━━●            │
│        ┃                            ┃            │
│        ┃                            ┃            │
│        ┃          30m               ┃ 30m        │
│        ┃                            ┃            │
│        ┃                            ┃            │
│   P0 (10, 10)           30m         P1 (40, 10) │ 10m
│        ●━━━━━━━━━━━━━━━━━━━━━━━━━━●            │
│                                                 │
└─────────────────────────────────────────────────┘
0m     10m                            40m        50m
```

### 순찰 포인트 좌표
| 포인트 | 좌표 (x, y) | 설명 |
|--------|------------|------|
| P0 | (10.0, 10.0) | 좌하단 (왼쪽 아래) |
| P1 | (40.0, 10.0) | 우하단 (오른쪽 아래) |
| P2 | (40.0, 40.0) | 우상단 (오른쪽 위) |
| P3 | (10.0, 40.0) | 좌상단 (왼쪽 위) |

### 경로 거리
| 구간 | 거리 | 유형 |
|------|------|------|
| P0 → P1 | 30.0m | 수평 |
| P1 → P2 | 30.0m | 수직 |
| P2 → P3 | 30.0m | 수평 |
| P3 → P0 | 30.0m | 수직 |
| **전체 경로** | **120.0m** | 1회 순찰 |

### 로봇 성능
- **최대 속도**: 1.5 m/s
- **1회 순찰 시간**: ~80초 (약 1.3분)
- **10분 에피소드**: 약 7-8회 순찰 가능

---

## 💡 설계 기준 (Design Rationale)

### 1. **테스트 및 데모 목적**
현재 맵은 다음 목적으로 설계되었습니다:

✅ **간단명료한 구조**
- 정사각형 패턴으로 이해하기 쉬움
- 대칭적 구조로 분석 용이
- 빠른 프로토타이핑 가능

✅ **시각화 친화적**
- 그래프로 표현하기 쉬움
- 로봇 경로 추적 명확
- 커버리지 분석 직관적

### 2. **균형잡힌 커버리지**

✅ **공간 분할**
- 4개 코너 포인트가 맵을 4등분
- 각 포인트가 12.5m × 12.5m 영역 담당
- 중앙 영역도 순찰 경로에 포함

✅ **일정한 거리**
- 모든 직선 구간이 30m로 동일
- 예측 가능한 이동 시간
- 학습 안정성 향상

### 3. **현실적인 스케일**

✅ **실제 환경 기반**
- **50m × 50m**:
  - 중형 건물 1개 층 크기
  - 야외 주차장 구역
  - 캠퍼스 건물 1층

✅ **실제 로봇 사양**
- **1.5 m/s**: Unitree Go2 실제 최대 속도
- **배터리**: 100Wh (5시간 운영)
- **LiDAR**: 10m 범위 (실제 센서 기준)

### 4. **확장 가능성**

✅ **쉬운 커스터마이징**
- YAML 파일 수정만으로 변경 가능
- 순찰 포인트 개수 제한 없음
- 다양한 패턴 지원

---

## 🔧 커스터마이징 방법

### 방법 1: 기본 설정 수정
`configs/default.yaml` 파일을 직접 편집:

```yaml
env:
  map_width: 50.0
  map_height: 50.0
  patrol_points:
    - [10.0, 10.0]  # 여기를 수정
    - [40.0, 10.0]
    - [40.0, 40.0]
    - [10.0, 40.0]
```

### 방법 2: 새로운 설정 파일 생성

#### 예시 1: 복도형 순찰 (긴 직선 경로)
`configs/corridor.yaml`:
```yaml
env:
  map_width: 60.0
  map_height: 20.0
  patrol_points:
    - [10.0, 10.0]
    - [20.0, 10.0]
    - [30.0, 10.0]
    - [40.0, 10.0]
    - [50.0, 10.0]
  event_generation_rate: 3.0  # 좁은 공간이므로 이벤트 적게

# 사용:
# python scripts/train.py --config configs/corridor.yaml
```

#### 예시 2: L자형 건물
`configs/l_shaped.yaml`:
```yaml
env:
  map_width: 50.0
  map_height: 50.0
  patrol_points:
    - [10.0, 10.0]
    - [40.0, 10.0]
    - [40.0, 25.0]
    - [25.0, 25.0]
    - [25.0, 40.0]
    - [10.0, 40.0]
  num_candidates: 6  # 포인트가 많아도 후보 수는 유지
```

#### 예시 3: 고밀도 순찰 (8개 포인트)
`configs/high_density.yaml`:
```yaml
env:
  map_width: 50.0
  map_height: 50.0
  patrol_points:
    - [10.0, 10.0]
    - [25.0, 10.0]
    - [40.0, 10.0]
    - [40.0, 25.0]
    - [40.0, 40.0]
    - [25.0, 40.0]
    - [10.0, 40.0]
    - [10.0, 25.0]
  event_generation_rate: 8.0  # 포인트 많아서 이벤트도 증가
```

#### 예시 4: 실제 건물 (서울대 302동 1층)
`configs/building_302.yaml`:
```yaml
env:
  map_width: 80.0  # 실제 건물 크기
  map_height: 40.0
  patrol_points:
    - [10.0, 10.0]  # 현관 입구
    - [30.0, 10.0]  # 로비
    - [50.0, 10.0]  # 복도 중간
    - [70.0, 10.0]  # 비상구
    - [70.0, 30.0]  # 계단실
    - [50.0, 30.0]  # 실험실 구역
    - [30.0, 30.0]  # 사무실 구역
    - [10.0, 30.0]  # 회의실
  patrol_point_priorities:
    - 1.5  # 현관 (중요)
    - 2.0  # 로비 (매우 중요)
    - 1.0  # 복도
    - 1.5  # 비상구 (중요)
    - 1.0  # 계단실
    - 1.2  # 실험실
    - 1.0  # 사무실
    - 0.8  # 회의실 (덜 중요)
  robot_max_velocity: 1.0  # 실내라서 속도 제한
  event_generation_rate: 10.0  # 넓은 공간
```

---

## 📊 맵 설정이 학습에 미치는 영향

### 1. **맵 크기**
- **작은 맵** (< 30m):
  - ✅ 빠른 학습
  - ✅ 적은 탐색 시간
  - ⚠️ 제한된 복잡도

- **큰 맵** (> 100m):
  - ⚠️ 느린 학습
  - ✅ 현실적인 시나리오
  - ⚠️ 긴 에피소드 시간

### 2. **순찰 포인트 개수**
- **적은 포인트** (2-4개):
  - ✅ 단순한 action space
  - ✅ 빠른 수렴
  - ⚠️ 제한된 전략

- **많은 포인트** (> 8개):
  - ⚠️ 복잡한 조합
  - ✅ 다양한 전략 학습
  - ⚠️ 학습 시간 증가

### 3. **이벤트 발생률**
- **낮은 발생률** (< 3.0):
  - 주로 순찰 중심
  - 커버리지 최적화 학습

- **높은 발생률** (> 8.0):
  - 주로 이벤트 대응 중심
  - 긴급 상황 처리 학습

---

## 🎯 권장 설정

### 초기 학습 / 테스트
```yaml
# configs/quick_test.yaml
env:
  map_width: 30.0
  map_height: 30.0
  patrol_points:
    - [10.0, 10.0]
    - [20.0, 10.0]
    - [20.0, 20.0]
    - [10.0, 20.0]
  event_generation_rate: 3.0
  max_episode_time: 300.0  # 5분
```

### 표준 학습
```yaml
# configs/default.yaml (현재 설정)
env:
  map_width: 50.0
  map_height: 50.0
  patrol_points: [4개 정사각형]
  event_generation_rate: 5.0
  max_episode_time: 600.0  # 10분
```

### 고급 학습 / 실전
```yaml
# configs/realistic.yaml
env:
  map_width: 100.0
  map_height: 60.0
  patrol_points: [8-12개, 실제 배치]
  event_generation_rate: 10.0
  max_episode_time: 1800.0  # 30분
```

---

## 🚀 사용 예시

### 기본 설정으로 학습
```bash
python scripts/train.py
```

### 커스텀 설정으로 학습
```bash
python scripts/train.py --config configs/building_302.yaml
```

### 여러 설정 비교
```bash
# 각 설정으로 학습
python scripts/train.py --config configs/default.yaml --seed 42
python scripts/train.py --config configs/corridor.yaml --seed 42
python scripts/train.py --config configs/high_density.yaml --seed 42

# 결과 비교
python scripts/evaluate.py --model checkpoints/default/final.pth
python scripts/evaluate.py --model checkpoints/corridor/final.pth
python scripts/evaluate.py --model checkpoints/high_density/final.pth
```

---

## 📈 맵 시각화

### 코드로 맵 확인
```python
from rl_dispatch.core.config import EnvConfig
import matplotlib.pyplot as plt

# 설정 로드
config = EnvConfig.load_yaml("configs/default.yaml")

# 시각화
fig, ax = plt.subplots(figsize=(10, 10))

# 맵 경계
ax.add_patch(plt.Rectangle(
    (0, 0), config.map_width, config.map_height,
    fill=False, edgecolor='black', linewidth=2
))

# 순찰 포인트
patrol_x = [pt[0] for pt in config.patrol_points]
patrol_y = [pt[1] for pt in config.patrol_points]
ax.scatter(patrol_x, patrol_y, s=300, c='blue', marker='o')

# 순찰 경로
route_x = patrol_x + [patrol_x[0]]
route_y = patrol_y + [patrol_y[0]]
ax.plot(route_x, route_y, 'b--', alpha=0.5)

ax.set_xlim(-5, config.map_width + 5)
ax.set_ylim(-5, config.map_height + 5)
ax.set_aspect('equal')
plt.title('Patrol Map Layout')
plt.show()
```

### 스크립트로 시각화
```bash
# 맵 레이아웃 확인
python scripts/visualize_map.py

# 학습 결과 경로 시각화
python scripts/evaluate.py --model checkpoints/final.pth --visualize
```

---

## ❓ FAQ

### Q: 맵 크기를 변경하면 학습을 다시 해야 하나요?
**A**: 네, 맵 구성이 변경되면 관측값과 보상이 달라지므로 새로 학습해야 합니다.

### Q: 순찰 포인트는 몇 개까지 가능한가요?
**A**: 최소 2개 이상이면 제한 없습니다. 다만 너무 많으면 (>15개) 학습이 느려질 수 있습니다.

### Q: 실제 건물에 적용하려면?
**A**:
1. 건물 평면도에서 주요 순찰 지점 선정
2. 실제 거리 측정하여 좌표 변환
3. configs/my_building.yaml 생성
4. 시뮬레이션으로 먼저 테스트
5. Gazebo로 검증 후 실제 로봇 배포

### Q: 우선순위(priority)는 어떻게 설정하나요?
**A**:
- 1.0: 보통 중요도 (기본값)
- 1.5-2.0: 높은 중요도 (현관, 로비 등)
- 0.5-0.8: 낮은 중요도 (창고, 비상구 등)

---

## 📚 참고 자료

- **설정 파일 문법**: `configs/README.md`
- **환경 구성**: `src/rl_dispatch/core/config.py`
- **시각화 예시**: `src/rl_dispatch/utils/visualization.py`
- **전체 문서**: `README.md`, `QUICK_START.md`

---

**마지막 업데이트**: 2025-12-29
**작성자**: 박용준 (YJP)
